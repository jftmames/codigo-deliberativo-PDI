import streamlit as st

st.set_page_config(page_title="LexDomus-IP", page_icon="🗃️", layout="centered")

st.title("LexDomus-IP · MVP deliberativo jurídico PI")
st.write("¡Hola! Streamlit corriendo en GitHub Codespaces.")
