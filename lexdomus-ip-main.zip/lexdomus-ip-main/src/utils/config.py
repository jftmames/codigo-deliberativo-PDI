from pydantic import BaseSettings, Field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]  # raíz del repo


class Settings(BaseSettings):
    openai_api_key: str = Field(..., env="OPENAI_API_KEY")

    class Config:
        env_file = ROOT / ".env"
        env_file_encoding = "utf-8"


settings = Settings()
