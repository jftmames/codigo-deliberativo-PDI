# src/etl/load_docs.py
from pathlib import Path


def load_files(folder: Path) -> list[str]:
    return [p.read_text(encoding="utf-8") for p in folder.glob("**/*.txt")]
