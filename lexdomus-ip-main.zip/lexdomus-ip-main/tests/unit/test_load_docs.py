# tests/unit/test_load_docs.py
from pathlib import Path
from lexdomus.etl.load_docs import load_files


def test_load_files(tmp_path: Path):
    # Arrange
    a = tmp_path / "a.txt"
    b = tmp_path / "sub" / "b.txt"
    b.parent.mkdir()
    a.write_text("uno")
    b.write_text("dos")

    # Act
    textos = load_files(tmp_path)

    # Assert
    assert textos == ["uno", "dos"]
