# lexdomus-mvp
Desarrollo MVP deliberativo jurídico PI
